var type =  new Typed("#head",{
    strings: ["Sem erros, não há progresso; sem progresso, não há inovação."],
    typeSpeed:30,
    startDelay:10,
    cursorChar: ""

})

window.onload = function () {
    new Typed("#head",{
        strings: ["Sem erros, não há progresso; sem progresso, não há inovação."],
        typeSpeed:30,
        startDelay:10,
        cursorChar: "",
    },
    anime({
      targets:'#head',
      opacity:"100%",
      duration:5000,
      easing: 'easeInOutQuad'
    }),
    anime({
        targets: '#blob1',
        right: '-1%',
        bottom:'-1%',
        rotate:'390deg',
        easing: 'easeInOutQuad',
        duration: 2200,
        opacity:"30%"
      }),
      anime({
        targets: '#blob2',
        left: '-1%',
        bottom:'-1%',
        rotate:'-390deg',
        easing: 'easeInOutQuad',
        duration: 2200,
        opacity:"30%"
      }),
      anime({
        targets: '#blob3',
        right: '-20%',
        top:'-30%',
        rotate:'370deg',
        easing: 'easeInOutQuad',
        duration: 2200,
        opacity:"30%"
      }),
      anime({
        targets: '#blob4',
        left: '-30%',
        top:'-30%',
        rotate:'-370deg',
        easing: 'easeInOutQuad',
        duration: 2200,
        opacity:"30%"
      })
)}
